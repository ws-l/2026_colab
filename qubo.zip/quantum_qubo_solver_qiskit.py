"""
quantum_qubo_solver_qiskit.py
═══════════════════════════════════════════════════════════════════════════
Qiskit 실제 구현 버전 — Battery–Hydrogen Energy Systems QUBO 최적화
═══════════════════════════════════════════════════════════════════════════

이 파일은 quantum_qubo_solver.py (NumPy 시뮬레이션)의 Qiskit 교체 버전입니다.
quantum_energy_optimization.py 에서 import 한 줄만 바꾸면 됩니다:

    # 기존 (NumPy 시뮬레이션)
    from quantum_qubo_solver import (
        QAOASolver, VQESolver, GroverAnnealingSolver,
        run_quantum_optimization, QUBOResult,
    )

    # Qiskit 버전으로 교체
    from quantum_qubo_solver_qiskit import (
        QAOASolver, VQESolver, GroverAnnealingSolver,
        run_quantum_optimization, QUBOResult,
    )

설치
----
pip install qiskit qiskit-aer qiskit-algorithms qiskit-optimization

백엔드 선택
-----------
기본값: AerSimulator (로컬 시뮬레이터, 노이즈 없음)
실 양자 하드웨어: BACKEND 변수를 IBM Quantum 서비스로 교체

    from qiskit_ibm_runtime import QiskitRuntimeService
    service = QiskitRuntimeService(channel="ibm_quantum", token="YOUR_TOKEN")
    backend = service.least_busy(operational=True, simulator=False)
    # _make_sampler() 함수 내부를 수정하세요 (아래 참고)
"""

from __future__ import annotations

import time
import warnings
from dataclasses import dataclass, field
from typing import Optional

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")

# ── Qiskit imports ───────────────────────────────────────────────────────
from qiskit.circuit.library import TwoLocal, QAOAAnsatz

# qiskit_algorithms 0.3.x 는 Sampler V1 인터페이스를 요구합니다.
# AerSampler (V1) 을 사용하고, V2는 사용하지 않습니다.
from qiskit_aer.primitives import Sampler as AerSampler   # V1 Sampler

from qiskit_algorithms import QAOA, SamplingVQE
from qiskit_algorithms.optimizers import COBYLA, L_BFGS_B, SPSA

from qiskit_optimization import QuadraticProgram
from qiskit_optimization.algorithms import (
    MinimumEigenOptimizer,
    GroverOptimizer,
)
from qiskit_optimization.converters import QuadraticProgramToQubo


# ═══════════════════════════════════════════════════════════════════════
# 설정
# ═══════════════════════════════════════════════════════════════════════

N_SHOTS    = 4096
MAX_QUBITS = 20    # Qiskit은 회로 기반 → 변수 수 제한 없음
                   # (단 큰 값일수록 시뮬레이션 느림, 권장: ≤20)


# ═══════════════════════════════════════════════════════════════════════
# 공통 유틸리티 (quantum_qubo_solver.py 와 동일 인터페이스 유지)
# ═══════════════════════════════════════════════════════════════════════

def qubo_energy(x: np.ndarray, Q: np.ndarray) -> float:
    return float(x @ Q @ x)


def _spectral_reduce(Q: np.ndarray,
                     max_q: int = MAX_QUBITS
                     ) -> tuple[np.ndarray, np.ndarray]:
    """
    QUBO 차원 축소 (n → max_q).
    Qiskit 버전은 MAX_QUBITS=20 이므로 대부분 축소 불필요.
    """
    n = Q.shape[0]
    if n <= max_q:
        return Q, np.eye(n)
    Q_sym = (Q + Q.T) / 2.0
    eigvals, eigvecs = np.linalg.eigh(Q_sym)
    order = np.argsort(np.abs(eigvals))[::-1][:max_q]
    P     = eigvecs[:, order]
    return P.T @ Q_sym @ P, P


def _qubo_to_quadratic_program(Q_red: np.ndarray) -> QuadraticProgram:
    """
    numpy QUBO 행렬 → Qiskit QuadraticProgram 변환.

    QuadraticProgram은 qiskit_optimization 의 문제 표현 형식으로,
    MinimumEigenOptimizer / GroverOptimizer 에 직접 전달됩니다.
    """
    n  = Q_red.shape[0]
    qp = QuadraticProgram()
    for i in range(n):
        qp.binary_var(f"x{i}")

    # 대각: 선형항, 비대각: 이차항
    linear    = {f"x{i}": float(Q_red[i, i])           for i in range(n)}
    quadratic = {(f"x{i}", f"x{j}"): float(Q_red[i, j] + Q_red[j, i])
                 for i in range(n) for j in range(i + 1, n)
                 if Q_red[i, j] != 0 or Q_red[j, i] != 0}

    qp.minimize(linear=linear, quadratic=quadratic)
    return qp


def _make_sampler():
    """
    실 하드웨어 연결 시 이 함수만 수정하면 됩니다.

    [로컬 시뮬레이터 - 기본값]
        return AerSampler()

    [IBM Quantum 실 하드웨어]
        from qiskit_ibm_runtime import QiskitRuntimeService, Sampler
        service = QiskitRuntimeService(token="YOUR_TOKEN")
        backend = service.least_busy(operational=True, simulator=False)
        return Sampler(backend)   # V1 Sampler (ibm_runtime >= 0.20)
    """
    sampler = AerSampler()
    sampler.set_options(shots=N_SHOTS)   # V1 API: set_options 로 shots 설정
    return sampler


def _result_to_qubo_result(solver_name: str,
                            opt_result,          # OptimizationResult
                            Q_full: np.ndarray,
                            proj: np.ndarray,
                            n_qubits: int,
                            circuit_depth: int,
                            wall_time: float,
                            history: list[float],
                            optimal_params: Optional[np.ndarray] = None,
                            ) -> "QUBOResult":
    """
    Qiskit OptimizationResult → 공통 QUBOResult 변환.
    이 함수 덕분에 plot_all() 등 하위 코드는 변경 불필요.
    """
    x_red  = np.array(opt_result.x, dtype=float)
    x_full = np.round(np.clip(proj @ x_red, 0, 1)).astype(float)

    # counts 재구성 (Qiskit은 직접 counts를 주지 않으므로 best만 기록)
    best_bs = "".join(str(int(v)) for v in x_red)
    counts  = {best_bs: N_SHOTS}

    return QUBOResult(
        solver_name    = solver_name,
        best_bitstring = best_bs,
        best_x         = x_full,
        best_energy    = qubo_energy(x_full, Q_full),
        eigenvalue     = float(opt_result.fval),
        optimal_params = optimal_params,
        counts         = counts,
        iterations     = len(history) if history else 0,
        wall_time      = wall_time,
        n_qubits       = n_qubits,
        circuit_depth  = circuit_depth,
        history        = history,
    )


# ═══════════════════════════════════════════════════════════════════════
# Result 데이터클래스 (quantum_qubo_solver.py 와 완전 동일)
# ═══════════════════════════════════════════════════════════════════════

@dataclass
class QUBOResult:
    solver_name:     str
    best_bitstring:  str
    best_x:          np.ndarray
    best_energy:     float
    eigenvalue:      float
    optimal_params:  Optional[np.ndarray]
    counts:          dict
    iterations:      int
    wall_time:       float
    n_qubits:        int
    circuit_depth:   int
    history:         list = field(default_factory=list)

    def has_battery(self, bat_idx: list[int]) -> bool:
        return any(self.best_x[i] == 1 for i in bat_idx)

    def has_hydrogen(self, hyd_idx: list[int]) -> bool:
        return any(self.best_x[i] == 1 for i in hyd_idx)

    def summary(self) -> str:
        lines = [
            f"  Solver        : {self.solver_name}",
            f"  Qubits        : {self.n_qubits}",
            f"  Circuit depth : {self.circuit_depth}",
            f"  QUBO energy   : {self.best_energy:.4f}",
            f"  Eigenvalue    : {self.eigenvalue:.4f}",
            f"  Components    : {int(self.best_x.sum())} / {len(self.best_x)}",
            f"  Iterations    : {self.iterations}",
            f"  Wall time     : {self.wall_time:.2f}s",
        ]
        return "\n".join(lines)


# ═══════════════════════════════════════════════════════════════════════
# SOLVER 1 — QAOA  (qiskit_algorithms.QAOA)
# ═══════════════════════════════════════════════════════════════════════

class QAOASolver:
    """
    Qiskit QAOA 래퍼.

    내부 동작
    ---------
    1. QUBO 행렬 → QuadraticProgram → SparsePauliOp (Ising 연산자)
    2. QAOAAnsatz (p레이어 회로) 구성
    3. COBYLA 로 파라미터 최적화
    4. AerSimulator 로 최종 측정

    파라미터
    --------
    p          : QAOA 레이어 수 (reps). 클수록 정확하지만 느림.
    optimizer  : 'COBYLA' | 'SPSA' | 'L-BFGS-B'
    max_qubits : 스펙트럴 축소 상한 (Qiskit은 20 이하 권장)
    seed       : 재현성용 난수 시드
    """

    def __init__(self,
                 p:          int = 3,
                 optimizer:  str = "COBYLA",
                 max_qubits: int = MAX_QUBITS,
                 seed:       int = 0):
        self.p          = p
        self.optimizer  = optimizer
        self.max_qubits = max_qubits
        self.seed       = seed

    def _make_optimizer(self):
        opts = {
            "COBYLA":   COBYLA(maxiter=200),
            "SPSA":     SPSA(maxiter=200),
            "L-BFGS-B": L_BFGS_B(maxiter=200),
        }
        return opts.get(self.optimizer, COBYLA(maxiter=200))

    def run(self, Q: np.ndarray, codes: list[str]) -> QUBOResult:
        t0 = time.time()
        np.random.seed(self.seed)

        # ── 1. 차원 축소 ───────────────────────────────────────────────
        Q_red, proj = _spectral_reduce(Q, self.max_qubits)
        n           = Q_red.shape[0]

        # ── 2. QuadraticProgram 구성 ───────────────────────────────────
        qp = _qubo_to_quadratic_program(Q_red)

        # ── 3. QUBO 변환기 (이미 QUBO 형태이므로 pass-through) ─────────
        converter = QuadraticProgramToQubo()
        qp_qubo   = converter.convert(qp)

        # ── 4. Qiskit QAOA 설정 ────────────────────────────────────────
        history: list[float] = []

        def callback(eval_count, params, value, meta):
            history.append(float(value))

        sampler = _make_sampler()
        qaoa = QAOA(
            sampler   = sampler,
            optimizer = self._make_optimizer(),
            reps      = self.p,             # p 레이어
            callback  = callback,
        )

        # ── 5. 최적화 실행 ─────────────────────────────────────────────
        eigen_optimizer = MinimumEigenOptimizer(qaoa)
        opt_result      = eigen_optimizer.solve(qp_qubo)

        # 회로 깊이 추정
        try:
            ansatz = QAOAAnsatz(
                cost_operator = qp_qubo.to_ising()[0],
                reps          = self.p,
            )
            depth = ansatz.decompose().depth()
        except Exception:
            depth = 2 * self.p * n   # fallback

        return _result_to_qubo_result(
            solver_name    = f"QAOA (p={self.p})",
            opt_result     = opt_result,
            Q_full         = Q,
            proj           = proj,
            n_qubits       = n,
            circuit_depth  = depth,
            wall_time      = time.time() - t0,
            history        = history,
            optimal_params = None,
        )


# ═══════════════════════════════════════════════════════════════════════
# SOLVER 2 — VQE  (qiskit_algorithms.SamplingVQE + TwoLocal ansatz)
# ═══════════════════════════════════════════════════════════════════════

class VQESolver:
    """
    Qiskit SamplingVQE 래퍼 (하드웨어 효율 앤서츠).

    내부 동작
    ---------
    1. QUBO → QuadraticProgram → SparsePauliOp
    2. TwoLocal 앤서츠 (Ry 회전 + CX 얽힘, depth 레이어)
    3. L-BFGS-B 로 파라미터 최적화
    4. AerSimulator 측정

    파라미터
    --------
    depth      : 앤서츠 레이어 수 (reps). NumPy 버전의 depth 와 동일.
    optimizer  : 'L-BFGS-B' | 'COBYLA' | 'SPSA'
    """

    def __init__(self,
                 depth:      int = 3,
                 optimizer:  str = "L-BFGS-B",
                 max_qubits: int = MAX_QUBITS,
                 seed:       int = 0):
        self.depth      = depth
        self.optimizer  = optimizer
        self.max_qubits = max_qubits
        self.seed       = seed

    def _make_optimizer(self):
        opts = {
            "L-BFGS-B": L_BFGS_B(maxiter=300),
            "COBYLA":   COBYLA(maxiter=300),
            "SPSA":     SPSA(maxiter=300),
        }
        return opts.get(self.optimizer, L_BFGS_B(maxiter=300))

    def run(self, Q: np.ndarray, codes: list[str]) -> QUBOResult:
        t0 = time.time()
        np.random.seed(self.seed)

        Q_red, proj = _spectral_reduce(Q, self.max_qubits)
        n           = Q_red.shape[0]

        qp       = _qubo_to_quadratic_program(Q_red)
        converter = QuadraticProgramToQubo()
        qp_qubo   = converter.convert(qp)

        # ── TwoLocal 앤서츠 ────────────────────────────────────────────
        # rotation_blocks='ry'  : NumPy 버전의 Ry 레이어와 동일
        # entanglement='linear' : NumPy 버전의 CX ring 과 유사
        ansatz = TwoLocal(
            num_qubits          = n,
            rotation_blocks     = "ry",
            entanglement_blocks = "cx",
            entanglement        = "linear",
            reps                = self.depth,
        )

        history: list[float] = []

        def callback(eval_count, params, value, meta):
            history.append(float(value))

        sampler = _make_sampler()
        vqe = SamplingVQE(
            sampler   = sampler,
            ansatz    = ansatz,
            optimizer = self._make_optimizer(),
            callback  = callback,
        )

        eigen_optimizer = MinimumEigenOptimizer(vqe)
        opt_result      = eigen_optimizer.solve(qp_qubo)

        try:
            depth_actual = ansatz.decompose().depth()
        except Exception:
            depth_actual = self.depth * (n + n)   # fallback

        return _result_to_qubo_result(
            solver_name    = f"VQE (depth={self.depth})",
            opt_result     = opt_result,
            Q_full         = Q,
            proj           = proj,
            n_qubits       = n,
            circuit_depth  = depth_actual,
            wall_time      = time.time() - t0,
            history        = history,
            optimal_params = None,
        )


# ═══════════════════════════════════════════════════════════════════════
# SOLVER 3 — Grover  (qiskit_optimization.GroverOptimizer)
# ═══════════════════════════════════════════════════════════════════════

class GroverAnnealingSolver:
    """
    Qiskit GroverOptimizer 래퍼.

    Qiskit의 GroverOptimizer는 QUBO를 직접 받아 Grover 탐색으로 풀며,
    내부적으로 위상 오라클과 diffusion 연산자를 자동 구성합니다.

    파라미터
    --------
    n_grover_steps  : num_value_qubits (에너지 값을 표현하는 보조 큐비트 수).
                      클수록 정밀하지만 회로 깊이 증가.
    n_anneal_cycles : Qiskit GroverOptimizer 에는 어닐링 사이클 개념 없음.
                      대신 num_iterations 로 재시도 횟수로 사용.
    """

    def __init__(self,
                 n_grover_steps:  int = 4,
                 n_anneal_cycles: int = 15,
                 max_qubits:      int = MAX_QUBITS,
                 seed:            int = 0):
        self.k           = n_grover_steps
        self.cycles      = n_anneal_cycles
        self.max_qubits  = max_qubits
        self.seed        = seed

    def run(self, Q: np.ndarray, codes: list[str]) -> QUBOResult:
        t0 = time.time()
        np.random.seed(self.seed)

        Q_red, proj = _spectral_reduce(Q, self.max_qubits)
        n           = Q_red.shape[0]

        qp        = _qubo_to_quadratic_program(Q_red)
        converter  = QuadraticProgramToQubo()
        qp_qubo    = converter.convert(qp)

        # ── Qiskit GroverOptimizer ─────────────────────────────────────
        # num_value_qubits : NumPy 버전의 n_grover_steps 에 대응.
        #                    에너지 값을 이진수로 표현하는 큐비트 수.
        sampler = _make_sampler()
        grover_opt = GroverOptimizer(
            num_value_qubits = self.k,
            num_iterations   = self.cycles,   # 재시도 횟수
            sampler          = sampler,
        )

        opt_result = grover_opt.solve(qp_qubo)

        # 회로 깊이: n 데이터 큐비트 + k 값 큐비트, 각 반복마다 오라클+diffusion
        circuit_depth = (n + self.k) * self.cycles * 2

        return _result_to_qubo_result(
            solver_name    = f"Grover-SA (k={self.k}×{self.cycles})",
            opt_result     = opt_result,
            Q_full         = Q,
            proj           = proj,
            n_qubits       = n + self.k,
            circuit_depth  = circuit_depth,
            wall_time      = time.time() - t0,
            history        = [],              # Grover는 중간 이력 없음
            optimal_params = None,
        )


# ═══════════════════════════════════════════════════════════════════════
# MULTI-SOLVER RUNNER (quantum_qubo_solver.py 와 완전 동일한 시그니처)
# ═══════════════════════════════════════════════════════════════════════

def run_quantum_optimization(
    Q:              np.ndarray,
    codes:          list[str],
    battery_codes:  list[str],
    hydrogen_codes: list[str],
) -> tuple:
    """
    6개 솔버를 순차 실행하고 (sol_df, q_results) 반환.
    quantum_energy_optimization.py 의 호출부는 변경 불필요.
    """
    bat_idx = [codes.index(c) for c in battery_codes  if c in codes]
    hyd_idx = [codes.index(c) for c in hydrogen_codes if c in codes]

    solvers = [
        QAOASolver          (p=2,                    seed=0),
        QAOASolver          (p=4,                    seed=1),
        VQESolver           (depth=2,                seed=2),
        VQESolver           (depth=4,                seed=3),
        GroverAnnealingSolver(n_grover_steps=3,  n_anneal_cycles=12, seed=4),
        GroverAnnealingSolver(n_grover_steps=5,  n_anneal_cycles=18, seed=5),
    ]

    results: list[QUBOResult] = []
    rows:    list[dict]       = []

    print("\n[5] Quantum QUBO Optimization  [Qiskit backend]")
    print("    Algorithm          │ n_q │ depth │ energy    │ hybrid │  time")
    print("    ───────────────────┼─────┼───────┼───────────┼────────┼──────")

    for run_i, solver in enumerate(solvers):
        res     = solver.run(Q, codes)
        has_bat = res.has_battery(bat_idx)
        has_hyd = res.has_hydrogen(hyd_idx)
        hybrid  = has_bat and has_hyd
        results.append(res)

        rows.append({
            "run":           run_i,
            "solver":        res.solver_name,
            "energy":        res.best_energy,
            "n_selected":    int(res.best_x.sum()),
            "selected":      [codes[i] for i, v in enumerate(res.best_x) if v == 1],
            "has_battery":   has_bat,
            "has_hydrogen":  has_hyd,
            "is_hybrid":     hybrid,
            "wall_time":     res.wall_time,
            "n_qubits":      res.n_qubits,
            "circuit_depth": res.circuit_depth,
            "iterations":    res.iterations,
        })

        print(f"    {res.solver_name:19s}│ {res.n_qubits:3d} │ {res.circuit_depth:5d} │"
              f" {res.best_energy:9.3f} │  {'YES' if hybrid else 'NO ':3s}  │ {res.wall_time:.1f}s")

    sol_df = pd.DataFrame(rows)
    sol_df.attrs["q_results"] = results

    print("    ───────────────────┴─────┴───────┴───────────┴────────┴──────")
    n_hyb = sol_df["is_hybrid"].sum()
    best  = sol_df.loc[sol_df["energy"].idxmin()]
    print(f"    Hybrid solutions : {n_hyb}/{len(sol_df)}")
    print(f"    Best solver      : {best['solver']}")
    print(f"    Best energy      : {best['energy']:.4f}")
    print(f"    Config size      : {best['n_selected']} IPC components")

    return sol_df, results
