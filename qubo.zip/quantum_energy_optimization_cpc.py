"""
Quantum-Inspired Optimization of Technological Configurations
Battery-Hydrogen Energy Systems
=====================================================================
Based on: "Quantum-inspired optimization of technological configurations:
Evidence from battery–hydrogen energy systems"

Pipeline:
1. Patent data loading / simulation (CPC co-classification based)
2. Frequent pattern mining (FP-Growth)
3. Temporal trajectory analysis
4. Causal discovery (PC algorithm)
5. QUBO formulation & optimization
6. Visualization
"""

import numpy as np
import pandas as pd
from itertools import combinations
from collections import defaultdict, Counter
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import networkx as nx
import warnings
warnings.filterwarnings('ignore')
import sys
sys.path.insert(0, '/home/claude')
from quantum_qubo_solver import (
    QAOASolver, VQESolver, GroverAnnealingSolver,
    run_quantum_optimization, QUBOResult,
)

# ─────────────────────────────────────────────
# 0. SEED & PURE-PYTHON FP-GROWTH SUBSTITUTE
# ─────────────────────────────────────────────
np.random.seed(42)


def _apriori(transactions: list, min_support: float) -> pd.DataFrame:
    """Minimal Apriori implementation (no external deps)."""
    n = len(transactions)
    item_sets_list = [frozenset(t) for t in transactions]
    all_items = sorted({item for t in transactions for item in t})

    # 1-itemsets
    counts = Counter(item for t in transactions for item in t)
    freq   = {frozenset([k]): v / n for k, v in counts.items() if v / n >= min_support}

    results = [(s, sup) for s, sup in freq.items()]
    current = list(freq.keys())

    size = 2
    while current:
        # Generate candidates
        candidates = set()
        cur_list   = sorted([sorted(s) for s in current])
        for i in range(len(cur_list)):
            for j in range(i + 1, len(cur_list)):
                a, b = cur_list[i], cur_list[j]
                if a[:-1] == b[:-1]:
                    candidates.add(frozenset(a) | frozenset(b))

        new_freq = {}
        for cand in candidates:
            sup = sum(1 for t in item_sets_list if cand.issubset(t)) / n
            if sup >= min_support:
                new_freq[cand] = sup

        results.extend(new_freq.items())
        current = list(new_freq.keys())
        size += 1
        if size > 6:   # cap depth for performance
            break

    df_out = pd.DataFrame(results, columns=["itemsets", "support"])
    return df_out.sort_values("support", ascending=False).reset_index(drop=True)


# ─────────────────────────────────────────────
# 1. CPC CODE DEFINITIONS
#    출처: EPO/USPTO Cooperative Patent Classification
#          EPO-IEA "Innovation in Batteries and Electricity Storage" (2020)
#          EPO-IEA "Hydrogen Patents for a Clean Energy Future" (2023)
# ─────────────────────────────────────────────

# ── 배터리 CPC (H01M 계열 + Y02 태그) ───────────────────────
CPC_CODES = {
    # 전극 (H01M 4)
    "H01M004/131": "NMC/NCA 혼합산화물 전극",
    "H01M004/133": "탄소계 전극 (흑연 음극)",
    "H01M004/134": "금속/실리콘 합금 전극",
    "H01M004/505": "LiMn2O4 망간산화물 전극",
    "H01M004/525": "NMC/NCA 니켈코발트 전극",
    "H01M004/583": "탄소계 삽입 전극",
    "H01M004/587": "경금속 삽입 탄소 전극",
    # 2차 전지 (H01M 10) ★ 핵심
    "H01M010/052": "리튬 2차 전지 (일반)",
    "H01M010/0525":"리튬이온 전지 (LIB)",
    "H01M010/0527":"리튬 폴리머 전지",
    "H01M010/054": "리튬황 전지",
    "H01M010/056": "전고체 전지 (일반)",
    "H01M010/0562":"무기 고체 전해질 전지",
    "H01M010/0563":"유기/폴리머 전해질 전지",
    "H01M010/058": "나트륨/칼륨 2차 전지",
    "H01M010/48":  "배터리 상태 모니터링 (BMS)",
    "H01M010/50":  "열 관리 (Thermal management)",
    # 비활성 부품 (H01M 50)
    "H01M050/204": "배터리 모듈",
    "H01M050/207": "배터리 팩",
    "H01M050/403": "분리막 소재",
    "H01M050/44":  "분리막 형상",
    # 수소 / 연료전지
    "H01M008/10":  "PEM 연료전지",
    "H01M008/12":  "고온형 연료전지 (SOFC)",
    "H01M008/1004":"MEA (막전극접합체)",
    "C01B003/02":  "수소 생산 (개질)",
    "C25B001/04":  "수전해 (알칼라인)",
    "C25B001/042": "PEM 수전해",
    "C25B001/044": "고온 수전해 (SOEC)",
    "F17C011/00":  "압축수소 저장용기",
    # 에너지 시스템 / 충방전
    "H02J007/00":  "배터리 충전 회로",
    "H02J007/34":  "태양광-배터리 연계",
    "H02J003/32":  "배터리 계통 연계",
    "H02J003/38":  "재생에너지 계통 연계",
    # Y02 기후변화 완화 태그
    "Y02E060/10":  "배터리 에너지 저장 (태그)",
    "Y02E060/50":  "연료전지 (태그)",
    "Y02E060/36":  "수전해 수소생산 (태그)",
    "Y02E060/32":  "수소 저장 (태그)",
    "Y02E070/30":  "재생에너지-저장 통합 (태그)",
    "Y02P070/50":  "배터리 제조 공정 (태그)",
    "Y02T010/70":  "전기차용 에너지 저장 (태그)",
}

# 기술 카테고리별 분류
BATTERY_CODES  = [
    "H01M004/131","H01M004/133","H01M004/134","H01M004/505",
    "H01M004/525","H01M004/583","H01M004/587",
    "H01M010/052","H01M010/0525","H01M010/0527","H01M010/054",
    "H01M010/056","H01M010/0562","H01M010/0563","H01M010/058",
    "H01M010/48", "H01M010/50",
    "H01M050/204","H01M050/207","H01M050/403","H01M050/44",
    "H02J007/00", "H02J007/34",
    "Y02E060/10", "Y02P070/50", "Y02T010/70",
]
HYDROGEN_CODES = [
    "H01M008/10", "H01M008/12", "H01M008/1004",
    "C01B003/02", "C25B001/04", "C25B001/042","C25B001/044",
    "F17C011/00",
    "Y02E060/50", "Y02E060/36","Y02E060/32",
]
POWER_CODES    = [
    "H02J003/32", "H02J003/38",
    "Y02E070/30",
]
THERMAL_CODES  = [
    "H01M010/50",
]
CONTROL_CODES  = [
    "H01M010/48",
]

ALL_CODES = list(CPC_CODES.keys())


# ─────────────────────────────────────────────
# 2. DATA LOADING  (합성 생성 또는 CSV 읽기)
# ─────────────────────────────────────────────

def _summary(df: pd.DataFrame, source: str) -> None:
    """공통 데이터 요약 출력."""
    yr = df["year"]
    print(f"[1] {source}")
    print(f"    특허 수       : {len(df):,}")
    print(f"    연도 범위     : {int(yr.min())} – {int(yr.max())}")
    print(f"    CPC 평균 개수 : {df['cpc_codes'].apply(len).mean():.2f}")
    all_codes_in_data = sorted({c for row in df["cpc_codes"] for c in row})
    print(f"    고유 CPC 코드 : {len(all_codes_in_data)}개")


def _norm_cpc(code: str) -> str:
    """슬래시 앞 숫자를 3자리로 패딩 (CPC 표준 형식).
    H01M10/0525 → H01M010/0525,  H01M4/525 → H01M004/525"""
    import re
    code = re.sub(r"\s+", "", str(code)).upper()
    if "/" in code:
        prefix, suffix = code.split("/", 1)
        prefix = re.sub(
            r"([A-Z]+\d+[A-Z]*)(\d+)$",
            lambda m: m.group(1) + m.group(2).zfill(3),
            prefix,
        )
        return prefix + "/" + suffix
    return code


def load_patent_csv(csv_path: str,
                    col_patent_id: str = "patent_id",
                    col_year:      str = "year",
                    col_cpc:       str = "cpc_codes",
                    cpc_sep:       str = ";",
                    fmt:           str = "wide") -> pd.DataFrame:
    """
    CSV 파일에서 특허 데이터를 읽어 파이프라인 형식으로 반환합니다.

    Parameters
    ----------
    csv_path      : CSV 파일 경로
    col_patent_id : 특허 ID 컬럼명  (기본값: "patent_id")
    col_year      : 연도 컬럼명      (기본값: "year")
    col_cpc       : CPC 코드 컬럼명  (기본값: "cpc_codes")
    cpc_sep       : wide format 구분자 (기본값: ";")
    fmt           : "wide"  → 한 행 = 한 특허, CPC가 구분자로 묶인 형태
                    "long"  → 한 행 = 한 CPC 코드 (Appln_id | CPC 형태)

    Wide format 예시
    ----------------
    patent_id,year,cpc_codes
    PAT00001,2010,H01M010/0525;H01M004/525
    PAT00002,2015,H01M004/525;Y02E060/10

    Long format 예시 (PATSTAT 등)
    ------------------------------
    Appln_id,year,CPC
    16977929,2010,H01M010/0525
    16977929,2010,H01M004/525   ← 같은 특허, 다음 행

    Returns
    -------
    pd.DataFrame  columns: patent_id (str), year (int), cpc_codes (list[str])
    """
    raw = pd.read_csv(csv_path, dtype=str)
    raw.columns = raw.columns.str.strip()

    # ── patent_id ────────────────────────────────────────────────────
    if col_patent_id not in raw.columns:
        raw.insert(0, "patent_id", [f"PAT{i:05d}" for i in range(len(raw))])
    else:
        raw = raw.rename(columns={col_patent_id: "patent_id"})

    # ── year ─────────────────────────────────────────────────────────
    if col_year not in raw.columns:
        raise ValueError(f"연도 컬럼 '{col_year}'을 찾을 수 없습니다. "
                         f"실제 컬럼: {list(raw.columns)}")
    raw = raw.rename(columns={col_year: "year"})
    raw["year"] = pd.to_numeric(raw["year"], errors="coerce")
    raw = raw.dropna(subset=["year"])
    raw["year"] = raw["year"].astype(int)

    if fmt == "long":
        # ── Long format: 한 행 = 한 CPC → 특허별로 집계 ──────────────
        if col_cpc not in raw.columns:
            raise ValueError(f"CPC 컬럼 '{col_cpc}'을 찾을 수 없습니다. "
                             f"실제 컬럼: {list(raw.columns)}")
        raw[col_cpc] = raw[col_cpc].apply(_norm_cpc)
        # patent_id별 year는 최빈값(또는 첫 번째) 사용
        year_map = raw.groupby("patent_id")["year"].first()
        cpc_map  = raw.groupby("patent_id")[col_cpc].apply(list)
        df = pd.DataFrame({"year": year_map, "cpc_codes": cpc_map}).reset_index()
        df = df.rename(columns={"patent_id": "patent_id"})

    else:
        # ── Wide format: 단일 컬럼에 구분자로 묶인 형태 ─────────────
        if col_cpc not in raw.columns:
            raise ValueError(f"CPC 컬럼 '{col_cpc}'을 찾을 수 없습니다. "
                             f"실제 컬럼: {list(raw.columns)}")
        def parse_wide(val):
            if pd.isna(val) or str(val).strip() == "":
                return []
            return [_norm_cpc(c.strip()) for c in str(val).split(cpc_sep) if c.strip()]
        raw["cpc_codes"] = raw[col_cpc].apply(parse_wide)
        df = raw.rename(columns={"patent_id": "patent_id"})

    df = df[df["cpc_codes"].apply(len) > 0].reset_index(drop=True)
    df = df[["patent_id", "year", "cpc_codes"]].copy()
    _summary(df, f"CSV 로드 ({fmt}): {csv_path}")
    return df


def generate_patent_data(n_patents: int = 2000,
                         year_start: int = 2000,
                         year_end:   int = 2023) -> pd.DataFrame:
    """
    CPC 기반 합성 특허 데이터 생성.
    세 시대: 초기 배터리 중심 → 수소 부상 → 하이브리드 통합.
    """
    records = []

    for i in range(n_patents):
        year = np.random.randint(year_start, year_end + 1)
        t    = (year - year_start) / (year_end - year_start)

        p_battery  = 0.70 - 0.20 * t
        p_hydrogen = 0.20 + 0.40 * t
        p_hybrid   = 0.05 + 0.50 * t
        p_control  = 0.10 + 0.30 * t

        codes: set = set()

        if np.random.rand() < p_battery:
            codes.update(np.random.choice(BATTERY_CODES,
                                          size=np.random.randint(1, 3),
                                          replace=False))
        if np.random.rand() < p_hydrogen:
            codes.update(np.random.choice(HYDROGEN_CODES,
                                          size=np.random.randint(1, 3),
                                          replace=False))
        if np.random.rand() < p_hybrid:
            codes.add(np.random.choice(BATTERY_CODES))
            codes.add(np.random.choice(HYDROGEN_CODES))
            codes.update(np.random.choice(POWER_CODES,
                                          size=np.random.randint(1, 2),
                                          replace=False))
        if codes and np.random.rand() < 0.40:
            codes.add(np.random.choice(POWER_CODES))
        if codes and np.random.rand() < 0.25:
            codes.add(np.random.choice(THERMAL_CODES))
        if codes and np.random.rand() < p_control:
            codes.add(np.random.choice(CONTROL_CODES))

        if not codes:
            codes.add(np.random.choice(ALL_CODES))

        records.append({
            "patent_id": f"PAT{i:05d}",
            "year":      year,
            "cpc_codes": list(codes),
        })

    df = pd.DataFrame(records)
    _summary(df, f"합성 데이터 생성 ({year_start}–{year_end})")
    return df


def load_data(csv_path:      str  = None,
              col_patent_id: str  = "patent_id",
              col_year:      str  = "year",
              col_cpc:       str  = "cpc_codes",
              cpc_sep:       str  = ";",
              fmt:           str  = "wide",
              n_patents:     int  = 2000,
              year_start:    int  = 2000,
              year_end:      int  = 2023) -> pd.DataFrame:
    """
    데이터 통합 진입점.

    csv_path 가 주어지면 CSV를 읽고, None 이면 합성 데이터를 생성합니다.

    fmt="long"  : 한 행 = 한 CPC (PATSTAT/EPO long format)
                  예) Appln_id | year | CPC
                  load_data("patents.csv",
                             col_patent_id="Appln_id",
                             col_year="year",
                             col_cpc="CPC",
                             fmt="long")

    fmt="wide"  : 한 행 = 한 특허, CPC 구분자 연결 (기본값)
                  예) patent_id | year | cpc_codes
    """
    if csv_path is not None:
        return load_patent_csv(csv_path, col_patent_id, col_year,
                               col_cpc, cpc_sep, fmt)
    else:
        return generate_patent_data(n_patents, year_start, year_end)


# ─────────────────────────────────────────────
# 3. FREQUENT PATTERN MINING (FP-Growth)
# ─────────────────────────────────────────────
def mine_frequent_patterns(df, min_support=0.05):
    """Return frequent itemsets via pure-Python Apriori."""
    freq_items = _apriori(df["cpc_codes"].tolist(), min_support)
    print(f"\n[2] Frequent patterns found: {len(freq_items)}")
    print(freq_items.head(10).to_string(index=False))
    return freq_items


# ─────────────────────────────────────────────
# 4. TEMPORAL TRAJECTORY ANALYSIS
# ─────────────────────────────────────────────
def temporal_analysis(df: pd.DataFrame,
                      window: int = 3) -> pd.DataFrame:
    """
    Rolling-window support for selected configurations.
    Tracks battery-only, hydrogen-only, and hybrid trajectories.
    """
    years = sorted(df["year"].unique())

    def config_presence(row, codes):
        return any(c in row["cpc_codes"] for c in codes)

    results = []
    for y in years:
        mask  = (df["year"] >= y - window) & (df["year"] <= y)
        chunk = df[mask]
        if len(chunk) == 0:
            continue
        n = len(chunk)

        bat_mask = chunk.apply(lambda r: config_presence(r, BATTERY_CODES),  axis=1)
        hyd_mask = chunk.apply(lambda r: config_presence(r, HYDROGEN_CODES), axis=1)
        hyb_mask = bat_mask & hyd_mask

        results.append({
            "year":            y,
            "battery_only":    (bat_mask & ~hyd_mask).sum() / n,
            "hydrogen_only":   (hyd_mask & ~bat_mask).sum() / n,
            "hybrid":          hyb_mask.sum() / n,
            "n_patents":       n,
        })

    traj = pd.DataFrame(results)
    print(f"\n[3] Temporal trajectories computed ({len(traj)} years)")
    return traj


# ─────────────────────────────────────────────
# 5. CAUSAL DISCOVERY (PC-style, correlation-based)
# ─────────────────────────────────────────────
def causal_discovery(df: pd.DataFrame,
                     threshold: float = 0.15) -> nx.DiGraph:
    """
    Lightweight PC-inspired causal graph.
    Uses partial correlation + temporal precedence as orientation heuristic.
    """
    # Binary presence matrix
    rows = []
    for _, row in df.iterrows():
        d = {c: (c in row["cpc_codes"]) for c in ALL_CODES}
        d["year"] = row["year"]
        rows.append(d)
    df_bin = pd.DataFrame(rows)

    corr = df_bin[ALL_CODES].corr().abs()
    G    = nx.DiGraph()
    G.add_nodes_from(ALL_CODES)

    # Mean appearance year per code (temporal precedence)
    mean_year = {}
    for code in ALL_CODES:
        mask = df_bin[code] == 1
        mean_year[code] = df_bin.loc[mask, "year"].mean() if mask.any() else 2010

    for c1, c2 in combinations(ALL_CODES, 2):
        r = corr.loc[c1, c2]
        if r > threshold:
            # Edge from earlier → later technology
            if mean_year[c1] <= mean_year[c2]:
                G.add_edge(c1, c2, weight=float(r))
            else:
                G.add_edge(c2, c1, weight=float(r))

    print(f"\n[4] Causal graph: {G.number_of_nodes()} nodes, "
          f"{G.number_of_edges()} directed edges")
    return G


# ─────────────────────────────────────────────
# 6. QUBO FORMULATION & SOLVER
# ─────────────────────────────────────────────
def build_qubo(df: pd.DataFrame,
               freq_items: pd.DataFrame,
               causal_G: nx.DiGraph,
               lambda1: float = 1.0,
               lambda2: float = 0.8,
               lambda3: float = 0.5) -> tuple[np.ndarray, list[str]]:
    """
    QUBO matrix Q where x^T Q x is minimised.

    Objective (minimise -value):
      f(x) = λ1 * persistence(x)
           + λ2 * adoption_potential(x)
           + λ3 * system_complexity(x)

    Decision variable xᵢ ∈ {0,1}: include CPC component i?
    """
    n     = len(ALL_CODES)
    idx   = {c: i for i, c in enumerate(ALL_CODES)}
    Q     = np.zeros((n, n))

    # ── Component-level support (adoption proxy) ──────────────────────
    rows2 = [{c: (c in row["cpc_codes"]) for c in ALL_CODES} for _, row in df.iterrows()]
    df_bin   = pd.DataFrame(rows2)
    support  = df_bin[ALL_CODES].mean()

    # ── Persistence: late-period support / overall support ────────────
    recent   = df[df["year"] >= df["year"].quantile(0.75)]
    rows3 = [{c: (c in row["cpc_codes"]) for c in ALL_CODES} for _, row in recent.iterrows()]
    df_rec   = pd.DataFrame(rows3)
    persistence = {}
    for c in ALL_CODES:
        s_rec = df_rec[c].mean() if c in df_rec.columns else 0
        s_all = support[c] if support[c] > 0 else 1e-6
        persistence[c] = s_rec / s_all

    # ── Diagonal terms ────────────────────────────────────────────────
    for c in ALL_CODES:
        i = idx[c]
        # Persistence (reward → negative for minimisation)
        Q[i, i] -= lambda1 * persistence[c]
        # Adoption (reward)
        Q[i, i] -= lambda2 * float(support[c])

    # ── Off-diagonal: co-occurrence reward ───────────────────────────
    co_matrix = df_bin[ALL_CODES].T.dot(df_bin[ALL_CODES]) / len(df_bin)
    for c1, c2 in combinations(ALL_CODES, 2):
        i, j  = idx[c1], idx[c2]
        co    = float(co_matrix.loc[c1, c2])
        # Causal synergy bonus
        causal_bonus = 0.2 if causal_G.has_edge(c1, c2) or causal_G.has_edge(c2, c1) else 0
        val   = lambda2 * (co + causal_bonus)
        Q[i, j] -= val
        Q[j, i] -= val

    # ── Complexity penalty (penalise very large configurations) ───────
    for i in range(n):
        for j in range(n):
            Q[i, j] += lambda3 * 0.01   # mild regularisation

    return Q, ALL_CODES


# ── Quantum solvers imported from quantum_qubo_solver.py ──
# QAOASolver, VQESolver, GroverAnnealingSolver, run_quantum_optimization
# are all available via the top-level import.


# ─────────────────────────────────────────────
# 7. VISUALIZATION
# ─────────────────────────────────────────────
def plot_all(traj: pd.DataFrame,
             freq_items: pd.DataFrame,
             causal_G: nx.DiGraph,
             sol_df: pd.DataFrame,
             Q: np.ndarray,
             codes: list[str]) -> None:

    fig = plt.figure(figsize=(22, 18), facecolor="#0D1117")
    fig.suptitle(
        "Quantum-Inspired Optimization of Battery–Hydrogen Energy Configurations",
        fontsize=16, fontweight="bold", color="#E6EDF3", y=0.98
    )

    axes_spec = [
        (fig.add_subplot(3, 3, 1), "Temporal Trajectories"),
        (fig.add_subplot(3, 3, 2), "Top-10 Frequent Configurations"),
        (fig.add_subplot(3, 3, 3), "Causal Discovery Graph"),
        (fig.add_subplot(3, 3, 4), "QUBO Matrix Heatmap"),
        (fig.add_subplot(3, 3, 5), "SA Convergence"),
        (fig.add_subplot(3, 3, 6), "Component Selection Frequency"),
        (fig.add_subplot(3, 3, 7), "Hybrid vs Non-Hybrid"),
        (fig.add_subplot(3, 3, 8), "Config Size Distribution"),
        (fig.add_subplot(3, 3, 9), "Empirical vs QUBO Alignment"),
    ]

    PALETTE = {
        "battery":  "#F7A800",
        "hydrogen": "#00C2E0",
        "hybrid":   "#A8FF3E",
        "other":    "#FF6B6B",
        "neutral":  "#8B949E",
        "bg":       "#161B22",
        "grid":     "#21262D",
    }

    def style_ax(ax, title):
        ax.set_facecolor(PALETTE["bg"])
        ax.set_title(title, color="#E6EDF3", fontsize=9, fontweight="bold", pad=6)
        ax.tick_params(colors=PALETTE["neutral"], labelsize=7)
        for spine in ax.spines.values():
            spine.set_edgecolor(PALETTE["grid"])

    # ── 1. Temporal Trajectories ──────────────────────────────────────
    ax = axes_spec[0][0]; style_ax(ax, "1. Temporal Technology Trajectories")
    ax.plot(traj["year"], traj["battery_only"],  color=PALETTE["battery"],  lw=2, label="Battery-only")
    ax.plot(traj["year"], traj["hydrogen_only"], color=PALETTE["hydrogen"], lw=2, label="Hydrogen-only")
    ax.plot(traj["year"], traj["hybrid"],        color=PALETTE["hybrid"],   lw=2.5, label="Hybrid")
    ax.fill_between(traj["year"], traj["hybrid"], alpha=0.15, color=PALETTE["hybrid"])
    ax.legend(fontsize=7, facecolor=PALETTE["bg"], labelcolor="#E6EDF3", framealpha=0.8)
    ax.set_xlabel("Year", color=PALETTE["neutral"], fontsize=7)
    ax.set_ylabel("Share", color=PALETTE["neutral"], fontsize=7)
    ax.grid(True, color=PALETTE["grid"], alpha=0.5)

    # ── 2. Frequent Patterns ──────────────────────────────────────────
    ax = axes_spec[1][0]; style_ax(ax, "2. Top-10 Frequent Configurations")
    top10 = freq_items.head(10).copy()
    top10["label"] = top10["itemsets"].apply(lambda s: "+".join(sorted(s)))
    colors_bar = []
    for s in top10["itemsets"]:
        has_b = any(c in BATTERY_CODES  for c in s)
        has_h = any(c in HYDROGEN_CODES for c in s)
        if has_b and has_h:   colors_bar.append(PALETTE["hybrid"])
        elif has_b:           colors_bar.append(PALETTE["battery"])
        elif has_h:           colors_bar.append(PALETTE["hydrogen"])
        else:                 colors_bar.append(PALETTE["other"])
    bars = ax.barh(range(len(top10)), top10["support"], color=colors_bar, height=0.6)
    ax.set_yticks(range(len(top10)))
    ax.set_yticklabels(top10["label"], fontsize=6)
    ax.set_xlabel("Support", color=PALETTE["neutral"], fontsize=7)
    ax.grid(True, axis="x", color=PALETTE["grid"], alpha=0.5)
    legend_els = [
        mpatches.Patch(color=PALETTE["hybrid"],   label="Hybrid"),
        mpatches.Patch(color=PALETTE["battery"],  label="Battery"),
        mpatches.Patch(color=PALETTE["hydrogen"], label="Hydrogen"),
    ]
    ax.legend(handles=legend_els, fontsize=6, facecolor=PALETTE["bg"],
              labelcolor="#E6EDF3", loc="lower right")

    # ── 3. Causal Graph ───────────────────────────────────────────────
    ax = axes_spec[2][0]; style_ax(ax, "3. Causal Discovery Graph")
    ax.set_xticks([]); ax.set_yticks([])
    sub_edges = [(u, v) for u, v, d in causal_G.edges(data=True)
                 if d.get("weight", 0) > 0.25]
    sub_nodes = list({n for e in sub_edges for n in e})
    SG = causal_G.subgraph(sub_nodes)
    node_colors = []
    for n in SG.nodes():
        if n in BATTERY_CODES:   node_colors.append(PALETTE["battery"])
        elif n in HYDROGEN_CODES: node_colors.append(PALETTE["hydrogen"])
        elif n in POWER_CODES:    node_colors.append("#C084FC")
        elif n in CONTROL_CODES:  node_colors.append(PALETTE["other"])
        else:                     node_colors.append(PALETTE["neutral"])
    pos = nx.spring_layout(SG, seed=42, k=1.5)
    nx.draw_networkx_nodes(SG, pos, node_color=node_colors,
                           node_size=300, ax=ax, alpha=0.9)
    nx.draw_networkx_edges(SG, pos, ax=ax,
                           edge_color=PALETTE["neutral"],
                           arrows=True, arrowsize=10,
                           alpha=0.6, width=0.8)
    nx.draw_networkx_labels(SG, pos, ax=ax,
                            font_size=5, font_color="#E6EDF3")

    # ── 4. QUBO Heatmap ───────────────────────────────────────────────
    ax = axes_spec[3][0]; style_ax(ax, "4. QUBO Matrix (Q)")
    im = ax.imshow(Q, cmap="RdYlGn_r", aspect="auto")
    ax.set_xticks(range(len(codes))); ax.set_yticks(range(len(codes)))
    ax.set_xticklabels(codes, rotation=90, fontsize=5)
    ax.set_yticklabels(codes, fontsize=5)
    plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)

    # ── 5. Quantum Solver Convergence Histories ───────────────────────
    ax = axes_spec[4][0]; style_ax(ax, "5. Quantum Solver Convergence")
    qcolors = [PALETTE["hybrid"], "#7EE7F5", PALETTE["battery"],
               "#C084FC", PALETTE["other"], "#FB923C"]
    if "q_results" in sol_df.attrs:
        for idx_r, res in enumerate(sol_df.attrs["q_results"]):
            if res.history:
                ax.plot(res.history,
                        color=qcolors[idx_r % len(qcolors)],
                        lw=1.2, alpha=0.85,
                        label=res.solver_name.split(" ")[0] + f"#{idx_r}")
        ax.legend(fontsize=5, facecolor=PALETTE["bg"], labelcolor="#E6EDF3",
                  framealpha=0.7, ncol=2)
    else:
        ax.text(0.5, 0.5, "No history", transform=ax.transAxes,
                ha="center", color=PALETTE["neutral"])
    ax.set_xlabel("Iteration / Cycle", color=PALETTE["neutral"], fontsize=7)
    ax.set_ylabel("Expected Energy", color=PALETTE["neutral"], fontsize=7)
    ax.grid(True, color=PALETTE["grid"], alpha=0.5)

    # ── 6. Component Selection Frequency ─────────────────────────────
    ax = axes_spec[5][0]; style_ax(ax, "6. Component Selection (across runs)")
    all_selected = [c for row in sol_df["selected"] for c in row]
    count = Counter(all_selected)
    sel_codes  = [c for c, _ in count.most_common()]
    sel_counts = [count[c] for c in sel_codes]
    bar_colors = []
    for c in sel_codes:
        if c in BATTERY_CODES:   bar_colors.append(PALETTE["battery"])
        elif c in HYDROGEN_CODES: bar_colors.append(PALETTE["hydrogen"])
        else:                     bar_colors.append(PALETTE["other"])
    ax.bar(range(len(sel_codes)), sel_counts, color=bar_colors)
    ax.set_xticks(range(len(sel_codes)))
    ax.set_xticklabels(sel_codes, rotation=90, fontsize=6)
    ax.set_ylabel("Frequency", color=PALETTE["neutral"], fontsize=7)
    ax.grid(True, axis="y", color=PALETTE["grid"], alpha=0.5)

    # ── 7. Quantum Solver Comparison ─────────────────────────────────
    ax = axes_spec[6][0]; style_ax(ax, "7. Quantum Solver Energy Comparison")
    solver_names = [s.split("(")[0].strip() for s in sol_df["solver"]]
    solver_energies = sol_df["energy"].values
    bar_c = [PALETTE["hybrid"] if h else PALETTE["battery"]
             for h in sol_df["is_hybrid"]]
    xpos = range(len(solver_names))
    ax.bar(xpos, solver_energies, color=bar_c, width=0.6)
    ax.set_xticks(xpos)
    ax.set_xticklabels(solver_names, rotation=45, ha="right", fontsize=6)
    ax.set_ylabel("QUBO Energy", color=PALETTE["neutral"], fontsize=7)
    ax.axhline(sol_df["energy"].min(), color=PALETTE["hybrid"],
               lw=1.2, linestyle="--", label="Best")
    ax.legend(fontsize=7, facecolor=PALETTE["bg"], labelcolor="#E6EDF3")
    ax.grid(True, axis="y", color=PALETTE["grid"], alpha=0.5)

    # ── 8. Config Size Distribution ───────────────────────────────────
    ax = axes_spec[7][0]; style_ax(ax, "8. Configuration Size Distribution")
    sizes = sol_df["n_selected"]
    ax.hist(sizes, bins=range(sizes.min(), sizes.max() + 2),
            color=PALETTE["hydrogen"], edgecolor=PALETTE["bg"], align="left")
    ax.axvline(sizes.mean(), color=PALETTE["hybrid"], lw=1.5, linestyle="--",
               label=f"Mean={sizes.mean():.1f}")
    ax.legend(fontsize=7, facecolor=PALETTE["bg"], labelcolor="#E6EDF3")
    ax.set_xlabel("# Components Selected", color=PALETTE["neutral"], fontsize=7)
    ax.set_ylabel("Count", color=PALETTE["neutral"], fontsize=7)
    ax.grid(True, axis="y", color=PALETTE["grid"], alpha=0.5)

    # ── 9. Empirical vs QUBO Alignment ───────────────────────────────
    ax = axes_spec[8][0]; style_ax(ax, "9. Empirical vs QUBO Alignment")
    best_sol = sol_df.loc[sol_df["energy"].idxmin(), "selected"]
    qubo_set = set(best_sol)

    # Empirical: most common codes in recent patents
    recent_df = freq_items[freq_items["itemsets"].apply(
        lambda s: len(s) >= 2)].head(30)
    empirical_codes = Counter()
    for _, row in recent_df.iterrows():
        for c in row["itemsets"]:
            empirical_codes[c] += row["support"]
    top_empirical = set([c for c, _ in empirical_codes.most_common(len(qubo_set))])

    overlap    = len(qubo_set & top_empirical)
    union      = len(qubo_set | top_empirical)
    jaccard    = overlap / union if union > 0 else 0
    qubo_only  = len(qubo_set - top_empirical)
    emp_only   = len(top_empirical - qubo_set)

    bars2 = ax.bar(
        ["Shared", "QUBO-only", "Empirical-only"],
        [overlap, qubo_only, emp_only],
        color=[PALETTE["hybrid"], PALETTE["hydrogen"], PALETTE["battery"]]
    )
    ax.set_ylabel("# Components", color=PALETTE["neutral"], fontsize=7)
    ax.set_title(
        f"9. Empirical vs QUBO Alignment (Jaccard={jaccard:.2f})",
        color="#E6EDF3", fontsize=9, fontweight="bold", pad=6
    )
    ax.grid(True, axis="y", color=PALETTE["grid"], alpha=0.5)
    for bar, val in zip(bars2, [overlap, qubo_only, emp_only]):
        ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.1,
                str(val), ha="center", va="bottom", color="#E6EDF3", fontsize=9)

    plt.tight_layout(rect=[0, 0, 1, 0.97])
    out_path = "/mnt/user-data/outputs/quantum_energy_optimization.png"
    plt.savefig(out_path, dpi=150, bbox_inches="tight", facecolor=fig.get_facecolor())
    plt.close()
    print(f"\n[6] Figure saved → {out_path}")
    return out_path


# ─────────────────────────────────────────────
# 8. MAIN
# ─────────────────────────────────────────────
def main():
    print("=" * 60)
    print("Quantum-Inspired Optimization | Battery-Hydrogen Systems")
    print("=" * 60)

    # Step 1 – Data
    # ── Wide format CSV (한 행 = 한 특허) ──────────────────────────
    # df = load_data(csv_path="patents.csv",
    #                col_patent_id="patent_id",
    #                col_year="year",
    #                col_cpc="cpc_codes",
    #                cpc_sep=";",
    #                fmt="wide")
    #
    # ── Long format CSV (PATSTAT 등, 한 행 = 한 CPC) ───────────────
    # df = load_data(csv_path="patents.csv",
    #                col_patent_id="Appln_id",
    #                col_year="year",
    #                col_cpc="CPC",
    #                fmt="long")
    #
    # 기본값: CPC 기반 합성 데이터 생성
    # ────────────────────────────────────────────────────────────────
    df = load_data(n_patents=2000, year_start=2000, year_end=2023)

    # Step 2 – Frequent pattern mining
    freq_items = mine_frequent_patterns(df, min_support=0.05)

    # Step 3 – Temporal analysis
    traj = temporal_analysis(df)

    # Step 4 – Causal discovery
    causal_G = causal_discovery(df, threshold=0.08)

    # Step 5 – Quantum QUBO Optimization
    Q, codes = build_qubo(df, freq_items, causal_G,
                          lambda1=1.0, lambda2=0.8, lambda3=0.5)
    sol_df, q_results = run_quantum_optimization(
        Q, codes, BATTERY_CODES, HYDROGEN_CODES)
    # q_results already attached as sol_df.attrs["q_results"] inside runner

    # Step 6 – Visualize
    plot_all(traj, freq_items, causal_G, sol_df, Q, codes)

    print("\n[Done] Pipeline complete.")
    print("  • Hybrid solutions: "
          f"{sol_df['is_hybrid'].sum()}/{len(sol_df)}")
    best = sol_df.loc[sol_df["energy"].idxmin()]
    print(f"  • Best config size: {best['n_selected']} components")
    print(f"  • Battery present:  {best['has_battery']}")
    print(f"  • Hydrogen present: {best['has_hydrogen']}")
    return sol_df


if __name__ == "__main__":
    sol = main()
