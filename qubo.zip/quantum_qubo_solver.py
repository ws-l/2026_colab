"""
quantum_qubo_solver.py
═══════════════════════════════════════════════════════════════════════════
Quantum QUBO Solvers for Battery–Hydrogen Energy Systems
Paper: "Quantum-inspired optimization of technological configurations"
═══════════════════════════════════════════════════════════════════════════

Implements three quantum algorithms as exact statevector simulations,
mirroring the Qiskit 1.x ecosystem API structure.

  ┌────────────────────────┬────────────────────────────────────────────┐
  │ This module            │ Qiskit 1.x equivalent                      │
  ├────────────────────────┼────────────────────────────────────────────┤
  │ QAOASolver             │ qiskit_algorithms.QAOA                     │
  │ VQESolver              │ qiskit_algorithms.SamplingVQE              │
  │ GroverAnnealingSolver  │ qiskit_algorithms.Grover                   │
  │ run_quantum_optimization│ MinimumEigenOptimizer (multi-backend)     │
  └────────────────────────┴────────────────────────────────────────────┘

Performance strategy
────────────────────
All three solvers use the EIGENDECOMPOSITION trick:

  H = V Λ V†  (one-time eigh call, O(dim²))
  e^{-iθH}|ψ⟩ = V · diag(e^{-iθλ}) · V†|ψ⟩   (O(dim) per angle)

This makes repeated evaluations during classical optimisation ~1 ms each
instead of ~100 ms for scipy.linalg.expm, enabling practical runtime at
n_qubits = 8 (dim = 256).

To run on real quantum hardware, replace this file with:
  from qiskit_algorithms import QAOA, SamplingVQE, Grover
  from qiskit_algorithms.optimizers import COBYLA, L_BFGS_B
  from qiskit.primitives import StatevectorSampler
  (API is intentionally kept compatible)
"""

from __future__ import annotations

import time
import warnings
from dataclasses import dataclass, field
from typing import Optional

import numpy as np
from scipy.linalg import eigh
from scipy.optimize import minimize

warnings.filterwarnings("ignore")

# ── Global simulation constants ─────────────────────────────────────────
MAX_QUBITS = 8      # 2^8 = 256-dim statevector; dim×dim matrix = 512 KB
N_SHOTS    = 4096   # measurement samples per final circuit execution


# ═══════════════════════════════════════════════════════════════════════
# 1. QUBO ↔ ISING CONVERSION
# ═══════════════════════════════════════════════════════════════════════

def qubo_to_ising(Q: np.ndarray) -> tuple[np.ndarray, np.ndarray, float]:
    """
    Map  x^T Q x  (x∈{0,1}^n)  →  s^T J s + h^T s + offset  (s∈{±1}^n)
    via substitution  x_i = (1 − s_i) / 2.

    Qiskit equivalent:
        from qiskit_optimization.converters import LinearEqualityToPenalty
        SparsePauliOp.from_list(...)  # builds the Ising operator
    """
    n     = Q.shape[0]
    Q_sym = (Q + Q.T) / 2.0
    J     = np.zeros((n, n))
    h     = np.zeros(n)
    offset = 0.0
    for i in range(n):
        for j in range(i + 1, n):
            J[i, j] += Q_sym[i, j] / 4.0
            h[i]    -= Q_sym[i, j] / 4.0
            h[j]    -= Q_sym[i, j] / 4.0
            offset  += Q_sym[i, j] / 4.0
        h[i]   -= Q_sym[i, i] / 2.0
        offset += Q_sym[i, i] / 2.0
    return J, h, offset


def ising_energy(s: np.ndarray, J: np.ndarray, h: np.ndarray) -> float:
    return float(s @ J @ s + h @ s)


def qubo_energy(x: np.ndarray, Q: np.ndarray) -> float:
    return float(x @ Q @ x)


# ═══════════════════════════════════════════════════════════════════════
# 2. PAULI OPERATORS & HAMILTONIANS
# ═══════════════════════════════════════════════════════════════════════

def _pauli_z(n: int, k: int) -> np.ndarray:
    """Pauli-Z on qubit k of n-qubit register (2^n × 2^n)."""
    ops    = [np.eye(2)] * n
    ops[k] = np.diag([1.0, -1.0])
    M      = ops[0]
    for op in ops[1:]:
        M = np.kron(M, op)
    return M.astype(complex)


def _pauli_x(n: int, k: int) -> np.ndarray:
    """Pauli-X on qubit k."""
    ops    = [np.eye(2)] * n
    ops[k] = np.array([[0, 1], [1, 0]], dtype=float)
    M      = ops[0]
    for op in ops[1:]:
        M = np.kron(M, op)
    return M.astype(complex)


def build_cost_hamiltonian(J: np.ndarray, h: np.ndarray) -> np.ndarray:
    """
    H_C = Σ_{i<j} J_{ij} Z_i Z_j + Σ_i h_i Z_i

    Qiskit: SparsePauliOp.from_list([("ZZ", J_ij), ("Z", h_i), ...])
    """
    n   = len(h)
    dim = 2 ** n
    H   = np.zeros((dim, dim), dtype=complex)
    for i in range(n):
        H += h[i] * _pauli_z(n, i)
    for i in range(n):
        for j in range(i + 1, n):
            if J[i, j] != 0:
                H += J[i, j] * (_pauli_z(n, i) @ _pauli_z(n, j))
    return H


def build_mixer_hamiltonian(n: int) -> np.ndarray:
    """
    H_B = Σ_i X_i   (standard QAOA mixer / Grover diffusion generator)

    Qiskit: from qiskit.circuit.library import QAOAAnsatz (built-in mixer)
    """
    dim = 2 ** n
    H   = np.zeros((dim, dim), dtype=complex)
    for i in range(n):
        H += _pauli_x(n, i)
    return H


# ═══════════════════════════════════════════════════════════════════════
# 3. STATEVECTOR UTILITIES
# ═══════════════════════════════════════════════════════════════════════

def _uniform_sv(n: int) -> np.ndarray:
    """
    |+⟩^⊗n  — Hadamard-initialised statevector.
    Qiskit: QuantumCircuit(n).h(range(n))
    """
    dim = 2 ** n
    return np.ones(dim, dtype=complex) / np.sqrt(dim)


def _apply_exp(sv: np.ndarray,
               V:   np.ndarray,
               lam: np.ndarray,
               angle: float) -> np.ndarray:
    """
    Compute  e^{-i·angle·H}|sv⟩  efficiently using eigen-decomposition:
        H = V Λ V†  →  e^{-iθH} = V diag(e^{-iθλ}) V†

    Cost: O(dim²) for two matrix-vector products, vs O(dim³) for expm.
    After the one-time eigh() call, each angle evaluation takes ~1 ms.
    """
    coeff  = V.conj().T @ sv
    coeff *= np.exp(-1j * angle * lam)
    return V @ coeff


def _measure(sv: np.ndarray, n_shots: int = N_SHOTS) -> dict[str, int]:
    """
    Simulate projective measurement in the computational basis.
    Qiskit: StatevectorSampler(shots=n_shots).run(circuit)
    """
    probs   = np.abs(sv) ** 2
    probs  /= probs.sum()
    n       = int(round(np.log2(len(sv))))
    indices = np.random.choice(2 ** n, size=n_shots, p=probs)
    counts: dict[str, int] = {}
    for idx in indices:
        bs = format(idx, f"0{n}b")
        counts[bs] = counts.get(bs, 0) + 1
    return counts


def _best_sample(counts: dict[str, int],
                 J: np.ndarray,
                 h: np.ndarray,
                 energies_cache: Optional[np.ndarray] = None
                 ) -> tuple[str, float]:
    """Return the minimum-energy bitstring from a measurement result."""
    best_bs, best_E = None, np.inf
    for bs in counts:
        if energies_cache is not None:
            e = energies_cache[int(bs, 2)]
        else:
            s = np.array([1 - 2 * int(b) for b in bs], dtype=float)
            e = ising_energy(s, J, h)
        if e < best_E:
            best_E, best_bs = e, bs
    return best_bs, best_E


def _spectral_reduce(Q: np.ndarray,
                     max_q: int = MAX_QUBITS
                     ) -> tuple[np.ndarray, np.ndarray]:
    """
    Reduce QUBO dimension from n → max_q via spectral truncation.
    Keeps the max_q eigenvectors with largest |eigenvalue| (dominant
    energy directions). Back-projection recovers the full-dimension solution.

    Qiskit equivalent: QuadraticProgram.minimize() with variable bounds.
    """
    n = Q.shape[0]
    if n <= max_q:
        return Q, np.eye(n)
    Q_sym = (Q + Q.T) / 2.0
    eigvals, eigvecs = np.linalg.eigh(Q_sym)
    order = np.argsort(np.abs(eigvals))[::-1][:max_q]
    P     = eigvecs[:, order]          # n × max_q projection
    return P.T @ Q_sym @ P, P         # reduced (max_q × max_q), projector


# ═══════════════════════════════════════════════════════════════════════
# 4. RESULT DATACLASS
# ═══════════════════════════════════════════════════════════════════════

@dataclass
class QUBOResult:
    """
    Mirrors:
      qiskit_algorithms.minimum_eigensolvers.SamplingVQEResult
      qiskit_algorithms.minimum_eigensolvers.SamplingMinimumEigensolverResult
    """
    solver_name:     str
    best_bitstring:  str
    best_x:          np.ndarray   # full-dimension binary solution
    best_energy:     float        # QUBO objective value
    eigenvalue:      float        # Ising ground-state energy estimate
    optimal_params:  Optional[np.ndarray]
    counts:          dict[str, int]
    iterations:      int          # number of objective function evaluations
    wall_time:       float        # seconds
    n_qubits:        int
    circuit_depth:   int
    history:         list[float] = field(default_factory=list)

    def has_battery(self, bat_idx: list[int]) -> bool:
        return any(self.best_x[i] == 1 for i in bat_idx)

    def has_hydrogen(self, hyd_idx: list[int]) -> bool:
        return any(self.best_x[i] == 1 for i in hyd_idx)

    def summary(self) -> str:
        lines = [
            f"  Solver        : {self.solver_name}",
            f"  Qubits        : {self.n_qubits}",
            f"  Circuit depth : {self.circuit_depth}",
            f"  QUBO energy   : {self.best_energy:.4f}",
            f"  Eigenvalue    : {self.eigenvalue:.4f}",
            f"  Components    : {int(self.best_x.sum())} / {len(self.best_x)}",
            f"  Iterations    : {self.iterations}",
            f"  Wall time     : {self.wall_time:.2f}s",
        ]
        return "\n".join(lines)


# ═══════════════════════════════════════════════════════════════════════
# 5. SOLVER 1 — QAOA
#    Quantum Approximate Optimisation Algorithm
# ═══════════════════════════════════════════════════════════════════════

class QAOASolver:
    """
    QAOA statevector simulation.

    ─── Qiskit 1.x API mirror ─────────────────────────────────────────
    from qiskit_algorithms import QAOA
    from qiskit_algorithms.optimizers import COBYLA
    from qiskit.primitives import StatevectorSampler

    sampler = StatevectorSampler()
    optimizer = COBYLA(maxiter=200)
    qaoa = QAOA(sampler=sampler, optimizer=optimizer, reps=p)
    result = qaoa.compute_minimum_eigenvalue(ising_op)
    ───────────────────────────────────────────────────────────────────

    Quantum circuit ansatz (p layers):
      |ψ(γ,β)⟩ = ∏_{l=1}^{p} [ e^{-iβ_l H_B} · e^{-iγ_l H_C} ] |+⟩^⊗n

    Classical optimisation:
      min_{γ,β}  ⟨ψ(γ,β)| H_C |ψ(γ,β)⟩

    Complexity per objective call: O(2·p · dim²)
    Total (COBYLA ~150 calls, p=3, dim=256): ≈ 0.5 s
    """

    def __init__(self,
                 p:          int = 3,
                 optimizer:  str = "COBYLA",
                 max_qubits: int = MAX_QUBITS,
                 seed:       int = 0):
        self.p          = p
        self.optimizer  = optimizer
        self.max_qubits = max_qubits
        self.seed       = seed

    def run(self, Q: np.ndarray, codes: list[str]) -> QUBOResult:
        t0 = time.time()
        np.random.seed(self.seed)

        Q_red, proj     = _spectral_reduce(Q, self.max_qubits)
        n               = Q_red.shape[0]
        J, h, offset    = qubo_to_ising(Q_red)
        H_C             = build_cost_hamiltonian(J, h)
        H_B             = build_mixer_hamiltonian(n)
        sv0             = _uniform_sv(n)

        # One-time eigendecompositions (the key speedup vs expm)
        lc, Vc = eigh(H_C)   # H_C = Vc Λc Vc†
        lb, Vb = eigh(H_B)   # H_B = Vb Λb Vb†

        history: list[float] = []

        def objective(params: np.ndarray) -> float:
            gamma, beta = params[:self.p], params[self.p:]
            sv = sv0.copy()
            for l in range(self.p):
                sv = _apply_exp(sv, Vc, lc, gamma[l])  # e^{-iγ H_C}
                sv = _apply_exp(sv, Vb, lb, beta[l])   # e^{-iβ H_B}
            val = float(np.real(sv.conj() @ (H_C @ sv)))
            history.append(val)
            return val

        params0 = np.random.uniform(0, np.pi, 2 * self.p)
        res_opt = minimize(
            objective, params0,
            method=self.optimizer,
            options={"maxiter": 200, "rhobeg": 0.5},
        )

        # Final statevector with optimal parameters
        sv = sv0.copy()
        for l in range(self.p):
            sv = _apply_exp(sv, Vc, lc, res_opt.x[l])
            sv = _apply_exp(sv, Vb, lb, res_opt.x[self.p + l])

        counts          = _measure(sv)
        best_bs, best_E = _best_sample(counts, J, h)

        x_red  = np.array([float(b) for b in best_bs])
        x_full = np.round(np.clip(proj @ x_red, 0, 1)).astype(float)

        return QUBOResult(
            solver_name    = f"QAOA (p={self.p})",
            best_bitstring = best_bs,
            best_x         = x_full,
            best_energy    = qubo_energy(x_full, Q),
            eigenvalue     = best_E + offset,
            optimal_params = res_opt.x,
            counts         = counts,
            iterations     = len(history),
            wall_time      = time.time() - t0,
            n_qubits       = n,
            circuit_depth  = 2 * self.p * n,     # alternating layers
            history        = history,
        )


# ═══════════════════════════════════════════════════════════════════════
# 6. SOLVER 2 — VQE
#    Variational Quantum Eigensolver (hardware-efficient ansatz)
# ═══════════════════════════════════════════════════════════════════════

class VQESolver:
    """
    VQE with hardware-efficient Ry-CX ansatz.

    ─── Qiskit 1.x API mirror ─────────────────────────────────────────
    from qiskit_algorithms import SamplingVQE
    from qiskit.circuit.library import TwoLocal
    from qiskit_algorithms.optimizers import L_BFGS_B
    from qiskit.primitives import StatevectorSampler

    ansatz = TwoLocal(n, 'ry', 'cx', reps=depth, entanglement='linear')
    vqe = SamplingVQE(sampler=StatevectorSampler(),
                      ansatz=ansatz,
                      optimizer=L_BFGS_B(maxiter=300))
    result = vqe.compute_minimum_eigenvalue(ising_op)
    ───────────────────────────────────────────────────────────────────

    Variational ansatz (depth layers):
      |ψ(θ)⟩ = ∏_{d=1}^{depth} [ CX_ring · ∏_i Ry(θ_{d,i}) ] |0⟩^⊗n

    Each Ry layer is a tensor product of 2×2 rotations → applied as
    a single O(dim²) matrix-vector product via kron products.
    CX_ring is constructed once and cached.
    """

    def __init__(self,
                 depth:      int = 3,
                 optimizer:  str = "L-BFGS-B",
                 max_qubits: int = MAX_QUBITS,
                 seed:       int = 0):
        self.depth      = depth
        self.optimizer  = optimizer
        self.max_qubits = max_qubits
        self.seed       = seed

    @staticmethod
    def _ry_single(theta: float) -> np.ndarray:
        c, s = np.cos(theta / 2), np.sin(theta / 2)
        return np.array([[c, -s], [s, c]], dtype=complex)

    def _ry_layer(self, thetas: np.ndarray, n: int) -> np.ndarray:
        """⊗_i Ry(θ_i)  as a 2^n × 2^n matrix."""
        mat = self._ry_single(thetas[0])
        for i in range(1, n):
            mat = np.kron(mat, self._ry_single(thetas[i]))
        return mat

    @staticmethod
    def _cx_ring(n: int) -> np.ndarray:
        """
        CX ladder: CNOT_{ctrl=i, tgt=(i+1)%n} for i ∈ {0,...,n-1}.
        Qiskit: circuit.cx(i, (i+1)%n)  (linear entanglement)
        """
        dim = 2 ** n
        U   = np.eye(dim, dtype=complex)
        for ctrl in range(n):
            tgt = (ctrl + 1) % n
            CX  = np.eye(dim, dtype=complex)
            for row in range(dim):
                if (row >> (n - 1 - ctrl)) & 1:
                    flipped          = row ^ (1 << (n - 1 - tgt))
                    CX[row, row]     = 0
                    CX[flipped, row] = 1
            U = CX @ U
        return U

    def run(self, Q: np.ndarray, codes: list[str]) -> QUBOResult:
        t0 = time.time()
        np.random.seed(self.seed)

        Q_red, proj  = _spectral_reduce(Q, self.max_qubits)
        n            = Q_red.shape[0]
        J, h, offset = qubo_to_ising(Q_red)
        H_C          = build_cost_hamiltonian(J, h)
        CX           = self._cx_ring(n)          # cached (one build)
        lc, Vc       = eigh(H_C)                 # for energy evaluation

        history: list[float] = []

        def objective(theta: np.ndarray) -> float:
            sv = np.zeros(2 ** n, dtype=complex); sv[0] = 1.0
            for d in range(self.depth):
                sv = self._ry_layer(theta[d * n:(d + 1) * n], n) @ sv
                sv = CX @ sv
            val = float(np.real(sv.conj() @ (H_C @ sv)))
            history.append(val)
            return val

        theta0  = np.random.uniform(0, 2 * np.pi, self.depth * n)
        res_opt = minimize(
            objective, theta0,
            method=self.optimizer,
            options={"maxiter": 300},
        )

        # Final statevector
        sv = np.zeros(2 ** n, dtype=complex); sv[0] = 1.0
        for d in range(self.depth):
            sv = self._ry_layer(res_opt.x[d * n:(d + 1) * n], n) @ sv
            sv = CX @ sv

        counts          = _measure(sv)
        best_bs, best_E = _best_sample(counts, J, h)

        x_red  = np.array([float(b) for b in best_bs])
        x_full = np.round(np.clip(proj @ x_red, 0, 1)).astype(float)

        return QUBOResult(
            solver_name    = f"VQE (depth={self.depth})",
            best_bitstring = best_bs,
            best_x         = x_full,
            best_energy    = qubo_energy(x_full, Q),
            eigenvalue     = best_E + offset,
            optimal_params = res_opt.x,
            counts         = counts,
            iterations     = len(history),
            wall_time      = time.time() - t0,
            n_qubits       = n,
            circuit_depth  = self.depth * (n + n),   # Ry + CX per layer
            history        = history,
        )


# ═══════════════════════════════════════════════════════════════════════
# 7. SOLVER 3 — GROVER AMPLITUDE ANNEALING
# ═══════════════════════════════════════════════════════════════════════

class GroverAnnealingSolver:
    """
    Grover-inspired amplitude amplification with annealing threshold schedule.

    ─── Qiskit 1.x API mirror ─────────────────────────────────────────
    from qiskit_algorithms import Grover, AmplificationProblem
    from qiskit.primitives import StatevectorSampler

    oracle = PhaseOracle(f"({energy_expr}) < {threshold}")
    problem = AmplificationProblem(oracle, is_good_state=lambda bs: E(bs)<theta)
    grover = Grover(sampler=StatevectorSampler(), iterations=k)
    result = grover.amplify(problem)
    ───────────────────────────────────────────────────────────────────

    Algorithm:
      1. Initialise  |ψ⟩ = |+⟩^⊗n  (uniform superposition)
      2. For threshold θ in annealing schedule [θ_max → θ_min]:
           For k Grover steps:
             Phase oracle:  |x⟩ → −|x⟩  if E(x) < θ,  else |x⟩
             Diffusion:     D|ψ⟩ = 2⟨+|ψ⟩|+⟩ − |ψ⟩
      3. Sample final statevector; return best measurement.

    Oracle is a diagonal vector multiply (O(2^n)) — no matrix required.
    Ising energies for all 2^n basis states are pre-computed once.
    """

    def __init__(self,
                 n_grover_steps:  int = 4,
                 n_anneal_cycles: int = 15,
                 max_qubits:      int = MAX_QUBITS,
                 seed:            int = 0):
        self.k           = n_grover_steps
        self.cycles      = n_anneal_cycles
        self.max_qubits  = max_qubits
        self.seed        = seed

    def run(self, Q: np.ndarray, codes: list[str]) -> QUBOResult:
        t0 = time.time()
        np.random.seed(self.seed)

        Q_red, proj  = _spectral_reduce(Q, self.max_qubits)
        n            = Q_red.shape[0]
        dim          = 2 ** n
        J, h, offset = qubo_to_ising(Q_red)

        # Pre-compute Ising energy for every computational basis state
        all_s    = np.array(
            [[1 - 2 * int(b) for b in format(i, f"0{n}b")] for i in range(dim)],
            dtype=float,
        )
        energies = np.array([ising_energy(s, J, h) for s in all_s])

        # Annealing threshold schedule
        E_max      = energies.max()
        E_min      = energies.min()
        thresholds = np.linspace(E_max * 0.90, E_min * 1.05, self.cycles)

        sv      = _uniform_sv(n)
        sv0     = sv.copy()          # reference state for diffusion
        history: list[float] = []
        total_iters = 0

        for theta in thresholds:
            for _ in range(self.k):
                # ── Phase oracle (diagonal, O(2^n)) ──────────────────
                phase = np.where(energies < theta, -1.0 + 0j, 1.0 + 0j)
                sv    = sv * phase
                # ── Grover diffusion about |+⟩ ────────────────────────
                amp   = float(np.real(np.dot(sv0.conj(), sv)))
                sv    = 2.0 * amp * sv0 - sv
                sv   /= np.linalg.norm(sv)   # numerical renormalisation
                total_iters += 1
            # Track expected Ising energy (convergence signal)
            history.append(float((np.abs(sv) ** 2) @ energies))

        counts          = _measure(sv)
        best_bs, best_E = _best_sample(counts, J, h, energies_cache=energies)

        x_red  = np.array([float(b) for b in best_bs])
        x_full = np.round(np.clip(proj @ x_red, 0, 1)).astype(float)

        return QUBOResult(
            solver_name    = f"Grover-SA (k={self.k}×{self.cycles})",
            best_bitstring = best_bs,
            best_x         = x_full,
            best_energy    = qubo_energy(x_full, Q),
            eigenvalue     = best_E + offset,
            optimal_params = None,
            counts         = counts,
            iterations     = total_iters,
            wall_time      = time.time() - t0,
            n_qubits       = n,
            circuit_depth  = self.k * self.cycles * 2,
            history        = history,
        )


# ═══════════════════════════════════════════════════════════════════════
# 8. MULTI-SOLVER RUNNER
# ═══════════════════════════════════════════════════════════════════════

def run_quantum_optimization(
    Q:              np.ndarray,
    codes:          list[str],
    battery_codes:  list[str],
    hydrogen_codes: list[str],
) -> tuple:
    """
    Run all three quantum solvers (2 parameter variants each = 6 runs total)
    and return (sol_df, q_results) compatible with the main visualisation.

    Qiskit equivalent:
        MinimumEigenOptimizer(qaoa).solve(qp)
        MinimumEigenOptimizer(vqe).solve(qp)
        GroverOptimizer(n_key).solve(qp)
    """
    import pandas as pd

    bat_idx = [codes.index(c) for c in battery_codes  if c in codes]
    hyd_idx = [codes.index(c) for c in hydrogen_codes if c in codes]

    solvers = [
        QAOASolver          (p=2,                    seed=0),
        QAOASolver          (p=4,                    seed=1),
        VQESolver           (depth=2,                seed=2),
        VQESolver           (depth=4,                seed=3),
        GroverAnnealingSolver(n_grover_steps=3,  n_anneal_cycles=12, seed=4),
        GroverAnnealingSolver(n_grover_steps=5,  n_anneal_cycles=18, seed=5),
    ]

    results: list[QUBOResult] = []
    rows:    list[dict]       = []

    print("\n[5] Quantum QUBO Optimization")
    print("    Algorithm          │ n_q │ depth │ energy    │ hybrid │  time")
    print("    ───────────────────┼─────┼───────┼───────────┼────────┼──────")

    for run_i, solver in enumerate(solvers):
        res     = solver.run(Q, codes)
        has_bat = res.has_battery(bat_idx)
        has_hyd = res.has_hydrogen(hyd_idx)
        hybrid  = has_bat and has_hyd
        results.append(res)

        rows.append({
            "run":           run_i,
            "solver":        res.solver_name,
            "energy":        res.best_energy,
            "n_selected":    int(res.best_x.sum()),
            "selected":      [codes[i] for i, v in enumerate(res.best_x) if v == 1],
            "has_battery":   has_bat,
            "has_hydrogen":  has_hyd,
            "is_hybrid":     hybrid,
            "wall_time":     res.wall_time,
            "n_qubits":      res.n_qubits,
            "circuit_depth": res.circuit_depth,
            "iterations":    res.iterations,
        })

        print(f"    {res.solver_name:19s}│ {res.n_qubits:3d} │ {res.circuit_depth:5d} │"
              f" {res.best_energy:9.3f} │  {'YES' if hybrid else 'NO ':3s}  │ {res.wall_time:.1f}s")

    sol_df = pd.DataFrame(rows)
    sol_df.attrs["q_results"] = results   # carry histories for plotting

    print("    ───────────────────┴─────┴───────┴───────────┴────────┴──────")
    n_hyb = sol_df["is_hybrid"].sum()
    best  = sol_df.loc[sol_df["energy"].idxmin()]
    print(f"    Hybrid solutions : {n_hyb}/{len(sol_df)}")
    print(f"    Best solver      : {best['solver']}")
    print(f"    Best energy      : {best['energy']:.4f}")
    print(f"    Config size      : {best['n_selected']} IPC components")

    return sol_df, results
